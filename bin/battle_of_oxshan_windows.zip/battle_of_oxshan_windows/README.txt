In this game, you are with Oxshan, who is a wizard. He is getting attacked by enemies, and it is your job to survive for as long as possible.


Controls:

In the menu, select the option you want with the arrow keys, or WASD, and then press enter or space. You can also use the mouse to do all of these.

Move with WASD

Teleport to mouse location with Space

Shoot with left mouse button. Bullets go to mouse location.

The red potions are health potions, and the blue potions are invincibility potions. Press R to use a health potion, and press Q to use an
invincibility potion. The invincibility potion's effect lasts 3 seconds.

The game can be paused with Escape. The controls are the same as in the menu.

Grass tile was taken from here: http://img697.imageshack.us/img697/2385/grass2.png

Brick was taken from here: http://deadlyredcube.com/journal/TileBrick.jpg (this one got modified)

